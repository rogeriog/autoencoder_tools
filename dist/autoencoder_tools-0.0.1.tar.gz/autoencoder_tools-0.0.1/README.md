# Autoencoder Tools
A simple package to handle autoencoders in keras easily, this was developed
particularly for an autoencoder to be used along with MODNet, a machine 
learning tool for description of materials properties.